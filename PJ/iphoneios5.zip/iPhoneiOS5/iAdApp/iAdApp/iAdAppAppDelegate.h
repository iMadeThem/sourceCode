//
//  iAdAppAppDelegate.h
//  iAdApp
//
//  Created by Neil Smyth on 8/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class iAdAppViewController;

@interface iAdAppAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) iAdAppViewController *viewController;

@end
