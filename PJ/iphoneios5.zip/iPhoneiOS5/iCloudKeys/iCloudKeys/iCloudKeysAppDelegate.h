//
//  iCloudKeysAppDelegate.h
//  iCloudKeys
//
//  Created by Neil Smyth on 8/8/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class iCloudKeysViewController;

@interface iCloudKeysAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) iCloudKeysViewController *viewController;

@end
