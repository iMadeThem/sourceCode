//
//  iCloudStoreViewController.h
//  iCloudStore
//
//  Created by Neil Smyth on 8/8/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyDocument.h"

@interface iCloudStoreViewController : UIViewController
{
    MyDocument *document;
    NSURL *documentURL;
    NSURL *ubiquityURL;
    UITextView *textView;
    NSMetadataQuery *metadataQuery;
}
@property (strong, nonatomic) IBOutlet UITextView *textView;
@property (strong, nonatomic) NSURL *documentURL;
@property (strong, nonatomic) MyDocument *document;
@property (strong, nonatomic) NSURL *ubiquityURL;
@property (strong, nonatomic) NSMetadataQuery *metadataQuery;
-(IBAction)saveDocument;
@end
