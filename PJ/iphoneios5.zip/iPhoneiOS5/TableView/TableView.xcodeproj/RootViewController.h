//
//  RootViewController.h
//  TableView
//
//  Created by Neil Smyth on 7/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BooksViewController;

@interface RootViewController : UITableViewController
{
            NSArray *authorList;
            BooksViewController *booksController;
}
@property (nonatomic, strong) NSArray *authorList;
@property (nonatomic, retain) IBOutlet BooksViewController *booksController;
@end

