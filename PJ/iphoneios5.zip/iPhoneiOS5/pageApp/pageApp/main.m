//
//  main.m
//  pageApp
//
//  Created by Neil Smyth on 8/19/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "pageAppAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([pageAppAppDelegate class]));
    }
}
