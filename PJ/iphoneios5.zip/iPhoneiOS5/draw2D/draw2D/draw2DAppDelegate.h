//
//  draw2DAppDelegate.h
//  draw2D
//
//  Created by Neil Smyth on 8/3/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class draw2DViewController;

@interface draw2DAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) draw2DViewController *viewController;

@end
