//
//  main.m
//  TableExample
//
//  Created by Neil Smyth on 7/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "TableExampleAppDelegate.h"

int main(int argc, char *argv[])
{
    int retVal = 0;
    @autoreleasepool {
        retVal = UIApplicationMain(argc, argv, nil, NSStringFromClass([TableExampleAppDelegate class]));
    }
    return retVal;
}
