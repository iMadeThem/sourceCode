//
//  datePickerAppDelegate.h
//  datePicker
//
//  Created by Neil Smyth on 8/3/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class datePickerViewController;

@interface datePickerAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) datePickerViewController *viewController;

@end
