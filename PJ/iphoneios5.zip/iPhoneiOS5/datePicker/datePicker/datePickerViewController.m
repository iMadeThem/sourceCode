//
//  datePickerViewController.m
//  datePicker
//
//  Created by Neil Smyth on 8/3/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "datePickerViewController.h"

@implementation datePickerViewController
@synthesize datePicker, dateLabel;

-(void)getSelection
{
    NSLocale *usLocale = [[NSLocale alloc]
                           initWithLocaleIdentifier:@"en_US"];
    
    NSDate *pickerDate = [datePicker date];
    NSString *selectionString = [[NSString alloc] 
                                 initWithFormat:@"%@",
                                 [pickerDate descriptionWithLocale:usLocale]];
    dateLabel.text = selectionString;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    self.dateLabel = nil;
    self.datePicker = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
