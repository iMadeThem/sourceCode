//
//  touchMotionAppDelegate.h
//  touchMotion
//
//  Created by Neil Smyth on 8/3/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class touchMotionViewController;

@interface touchMotionAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) touchMotionViewController *viewController;

@end
