//
//  hideKeyboardViewController.h
//  hideKeyboard
//
//  Created by Neil Smyth on 8/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface hideKeyboardViewController : UIViewController {
    UITextField  *textField;
}
@property (strong, nonatomic) IBOutlet UITextField *textField;
-(IBAction)textFieldReturn:(id)sender;
-(IBAction)backgroundTouched:(id)sender;
@end
