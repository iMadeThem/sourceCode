/*
 * Exif parser
 */

#include "exif.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define SECTION_NUM 2

static const char *progName;
static const char *currentFile;
static int FilesMatched;

ImageInfo_t imageInfo;
static Section_t *sections = NULL;
static int sectionsAllocated;
static int sectionsRead;
//static int haveAll;
static int FOUND = false;


int main (int argc, char **argv) {
    int argn;
    char *arg;
    char resolution[32];
    progName = argv[0];

    for(argn = 1; argn < argc; argn++){
 	arg = argv[argn];
	if(arg[0] != '-')
	    break;
	if(!strncmp(arg, "-h", 2)) {
	    printf("Usage: ./exif file.jpg\n");
	    exit(EXIT_FAILURE);
	}
 	if(argn >= argc) {
 	    ErrFatal("Extra argument required.");
 	}
    }
    if(argn == argc) {
	ErrFatal("No files to process.");
    }
    
    for(;argn < argc; argn++) {
	printf("File ------------------- %d\n", argn);
	FilesMatched = false;
	ParseFile(argv[argn]);
	if(!FilesMatched) {
	    fprintf(stderr, "Error: No files matched '%s'\n", argv[argn]);
	}
	snprintf(resolution, 32, "%dx%d", imageInfo.Width, imageInfo.Height);
	printf("File '%s' parsed, resolution is %s.\n", currentFile,  resolution);
	FOUND = false;
    }

    return EXIT_SUCCESS;
}

void ParseFile(const char *FileName){
//    int Modified = false;
    ReadMode_t readMode;

    if(strlen(FileName) >= PATH_MAX - 1) {
	ErrFatal("file name too long!");
    }

    readMode = READ_METADATA;
    currentFile = FileName;
    FilesMatched = 1;

    ResetJpegSections();

    // Start with an empty image information structure.
    memset(&imageInfo, 0, sizeof(imageInfo));

#if 0
    imageInfo.FlashUsed = -1;
    imageInfo.MeteringMode = -1;
    imageInfo.Whitebalance = -1;
#endif

    strncpy(imageInfo.FileName, FileName, PATH_MAX);
    dump(imageInfo.FileName);

    if(!ReadJpegFile(FileName, READ_METADATA)) {
	return;
    }

//    Modified = true;
//    readMode = READ_IMAGE;   
}

void ResetJpegSections(void) {
    if(sections == NULL) {
	sections = (Section_t *)malloc(sizeof(Section_t) * SECTION_NUM);
	sectionsAllocated = SECTION_NUM;
    }
    sectionsRead = 0;
    //haveAll = 0;
}

int ReadJpegFile(const char *FileName, ReadMode_t ReadMode) {
    FILE *inFile;
    int ret = 0;

    inFile = fopen(FileName, "rb");

    if(inFile == NULL) {
	fprintf(stderr, "Can not open '%s'\n", FileName);
	return false;
    }
    // Scan JPEG headers
    ret = ReadJpegSections(inFile, ReadMode);
    if(!ret) {
	fprintf(stderr, "Not JPEG: %s\n", FileName);
    }

    fclose(inFile);

    if(ret == false) {
	DiscardData();
    }

    return ret;
}

// Parse the marker stream until SOS or EIO is met.
int ReadJpegSections(FILE *inFile, ReadMode_t ReadMode) {
    int a;
    //int HaveCom = false;

    a = fgetc(inFile);
    //printf("+++++: %d\n", a);
    if(a != 0xFF || fgetc(inFile) != M_SOI) {
	return false;
    }
//    imageInfo.JfifHeader.XDensity = imageInfo.JfifHeader.YDensity = 300;
//    imageInfo.JfifHeader.Resolutionunits = 1;
    while(!FOUND) {
	int itemLen;
	int prev;
	int marker = 0;
	int ll, lh, got;
	uchar *Data;

	CheckSectionsAllocated();

	prev = 0;
	for(a = 0; ;a++) {
	    marker = fgetc(inFile);
	    //printf("+++++marker: %02X\n", marker);
	    if(marker != 0xFF && prev == 0xFF) {
		break;
	    }
	    prev = marker;
	}
#if 0
	if(a > 10) {
	    fprintf(stderr, "Extraneous %d padding bytes before section %02X\n", a-1, marker);
	}
#endif

	sections[sectionsRead].type = marker;

	// Read the length of the section.
	lh = fgetc(inFile);
	ll = fgetc(inFile);
	itemLen = (lh << 8) | ll;
	
	if(itemLen < 2) {
	    ErrFatal("invalid marker");
	}

	sections[sectionsRead].size = itemLen;
	Data = (uchar *)malloc(itemLen);
	if(Data == NULL) {
	    ErrFatal("Could not allocate memory.");
	}
	sections[sectionsRead].data = Data;
	// Store first two pre-read bytes.
	Data[0] = (uchar)lh;
	Data[1] = (uchar)ll;
	got = fread(Data + 2, 1, itemLen - 2, inFile); // read the whole section

	if(got != (itemLen - 2)) {
	    ErrFatal("Premature end of file?");
	}
	//sectionsRead +=1;


	switch(marker) {
	case M_EOI:   // in case it's a tables-only JPEG stream
	    fprintf(stderr,"Reached End Of Image!\n");
	    return false;
	case M_SOF0: 
	case M_SOF1: 
	case M_SOF2: 
	case M_SOF3: 
	case M_SOF5: 
	case M_SOF6: 
	case M_SOF7: 
	case M_SOF9: 
	case M_SOF10:
	case M_SOF11:
	case M_SOF13:
	case M_SOF14:
	case M_SOF15:
	    process_SOFn(Data, marker);
	    free(Data);
	    Data = NULL;
	    break;
	default:
	    // Skip any other sections.

	    continue;    
	}
    }
    
    return true;
}

void process_SOFn(const uchar *Data, int marker) {
    int data_precision;// num_components;
    data_precision = Data[2];
    imageInfo.Height = Get16m(Data+3);
    imageInfo.Width = Get16m(Data+5);
    FOUND = true;

#if 0
    num_components = Data[7];

    if (num_components == 3){
        imageInfo.IsColor = 1;
    }else{
        imageInfo.IsColor = 0;
    }

    imageInfo.Process = marker;

    printf("JPEG image is %uw x %uh, %d color components, %d bits per sample\n",
	   imageInfo.Width, imageInfo.Height, num_components, data_precision);
#endif
}

void DiscardData(void) {
    //int a;

    for(int a = 0; a < sectionsRead;a++) {
	free(sections[a].data);
	sections[a].data = NULL;
    }
    memset(&imageInfo, 0, sizeof(imageInfo));
    sectionsRead = 0;
    //haveAll = 0;
}

int Get16m(const void *Short) {
    return (((uchar *)Short)[0] << 8) |((uchar *)Short)[1];
}

void CheckSectionsAllocated(void) {
    if(sectionsRead > sectionsAllocated) {
	ErrFatal("allocation screwup.");
    }
    if(sectionsRead >= sectionsAllocated) {
	sectionsAllocated += sectionsAllocated/2;
	sections = (Section_t *)realloc(sections, sizeof(Section_t) * sectionsAllocated);
	if(sections == NULL) {
	    ErrFatal("Could not allocate data for entire image.");
	}
    }
}

void ErrFatal(const char *msg) {
    fprintf(stderr, "\nError: %s\n", msg);
    exit(EXIT_FAILURE);
}

void dump(char *msg){
    printf("+++DUMP: %s\n", msg);
}

