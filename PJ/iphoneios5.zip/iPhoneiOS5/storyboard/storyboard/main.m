//
//  main.m
//  storyboard
//
//  Created by Neil Smyth on 7/12/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "storyboardAppDelegate.h"

int main(int argc, char *argv[])
{
    int retVal = 0;
    @autoreleasepool {
        retVal = UIApplicationMain(argc, argv, nil, NSStringFromClass([storyboardAppDelegate class]));
    }
    return retVal;
}
