//
//  iAdAppViewController.m
//  iAdApp
//
//  Created by Neil Smyth on 8/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "iAdAppViewController.h"

@implementation iAdAppViewController
@synthesize tableView;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    bannerView = [[ADBannerView alloc] 
                  initWithFrame:CGRectZero];
    bannerView.requiredContentSizeIdentifiers = 
    [NSSet setWithObjects: 
     ADBannerContentSizeIdentifierPortrait,	
     ADBannerContentSizeIdentifierLandscape, nil];
    bannerView.delegate = self;

}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    self.tableView = nil;

}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    //return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
    if (UIInterfaceOrientationIsLandscape(interfaceOrientation))
        bannerView.currentContentSizeIdentifier =
        ADBannerContentSizeIdentifierLandscape;
    else
        bannerView.currentContentSizeIdentifier =
        ADBannerContentSizeIdentifierPortrait;
    return YES;


}

- (void)bannerViewDidLoadAd:(ADBannerView *)banner
{
    tableView.tableHeaderView = bannerView;
}

- (void)bannerViewWillLoadAd:(ADBannerView *)banner
{
    
}

-(void) didFailToReceiveAdWithError:(NSError *)error
{
    
}
@end
