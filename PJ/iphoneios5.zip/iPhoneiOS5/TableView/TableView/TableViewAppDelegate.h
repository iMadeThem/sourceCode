//
//  TableViewAppDelegate.h
//  TableView
//
//  Created by Neil Smyth on 7/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class RootViewController;

@interface TableViewAppDelegate : UIResponder <UIApplicationDelegate>

{
    UINavigationController *navigationController;
}
@property (strong, nonatomic) UINavigationController *navigationController;
@property (strong, nonatomic) UIWindow *window;

@end
