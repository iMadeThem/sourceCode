//
//  draw2D.m
//  draw2D
//
//  Created by Neil Smyth on 8/3/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "draw2D.h"

@implementation draw2D

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
    UIImage *myimage = [UIImage imageNamed:@"pumpkin.jpg"];
    
        
    CIImage *cimage = [[CIImage alloc] initWithImage:myimage];
 
    CIFilter *sepiaFilter = [CIFilter filterWithName:@"CISepiaTone"];
    
    [sepiaFilter setDefaults];
    [sepiaFilter setValue:cimage forKey:@"inputImage"];
    [sepiaFilter setValue:[NSNumber numberWithFloat:0.8f] forKey:@"inputIntensity"];
    
    CIImage * image = [sepiaFilter outputImage];
    CIContext * context = [CIContext contextWithOptions: nil];

    CGImageRef cgImage = [context createCGImage: image fromRect: image.extent];

    UIImage * resultUIImage = [UIImage imageWithCGImage: cgImage];
    CGRect imageRect =[[UIScreen mainScreen] bounds];
    
    [resultUIImage drawInRect:imageRect];
}


@end
