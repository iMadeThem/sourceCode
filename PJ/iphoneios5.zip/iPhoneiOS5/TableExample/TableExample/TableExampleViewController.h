//
//  TableExampleViewController.h
//  TableExample
//
//  Created by Neil Smyth on 7/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableExampleViewController : UIViewController
    <UITableViewDelegate, UITableViewDataSource>
{
    NSArray *colorNames;
}
@property (nonatomic, retain) NSArray *colorNames;
@end
