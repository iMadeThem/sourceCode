//
//  layoutViewController.h
//  layout
//
//  Created by Neil Smyth on 8/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface layoutViewController : UIViewController {
    UIButton *firstButton;
    UIButton *secondButton;
}
@property (strong, nonatomic) IBOutlet UIButton *firstButton;
@property (strong, nonatomic) IBOutlet UIButton *secondButton;
@end
