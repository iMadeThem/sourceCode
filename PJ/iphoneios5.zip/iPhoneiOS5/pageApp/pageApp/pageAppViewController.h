//
//  pageAppViewController.h
//  pageApp
//
//  Created by Neil Smyth on 8/19/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "contentViewController.h"

@interface pageAppViewController : UIViewController
       <UIPageViewControllerDataSource>
{
    UIPageViewController *pageController;
    NSArray *pageContent;
}
@property (strong, retain) UIPageViewController *pageController;
@property (strong, retain) NSArray *pageContent;
@end
