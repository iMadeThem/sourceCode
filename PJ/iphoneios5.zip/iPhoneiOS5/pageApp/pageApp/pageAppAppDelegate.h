//
//  pageAppAppDelegate.h
//  pageApp
//
//  Created by Neil Smyth on 8/19/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class pageAppViewController;

@interface pageAppAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) pageAppViewController *viewController;

@end
