//
//  pickerViewViewController.h
//  pickerView
//
//  Created by Neil Smyth on 8/3/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface pickerViewViewController : UIViewController
<UIPickerViewDelegate, UIPickerViewDataSource>
{
    UIPickerView       *picker;
    NSArray            *countryNames;
    NSArray            *exchangeRates;
    UILabel            *resultLabel;
    UITextField        *dollarText;
}
@property (strong, nonatomic) IBOutlet UIPickerView *picker;
@property (strong, nonatomic) IBOutlet UILabel *resultLabel;
@property (strong, nonatomic) IBOutlet UITextField *dollarText;
@property (strong, nonatomic) NSArray *countryNames;
@property (strong, nonatomic) NSArray *exchangeRates;
-(IBAction)textFieldReturn:(id)sender;
@end
