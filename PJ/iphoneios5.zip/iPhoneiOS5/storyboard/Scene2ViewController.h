//
//  Scene2ViewController.h
//  storyboard
//
//  Created by Neil Smyth on 7/12/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//



@interface Scene2ViewController : UIViewController

@end
