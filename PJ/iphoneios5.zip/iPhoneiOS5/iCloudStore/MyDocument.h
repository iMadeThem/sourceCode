//
//  MyDocument.h
//  iCloudStore
//
//  Created by Neil Smyth on 8/8/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyDocument : UIDocument
{
    NSString *userText;
}
@property (strong, nonatomic) NSString *userText;
@end