//
//  datePickerViewController.h
//  datePicker
//
//  Created by Neil Smyth on 8/3/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface datePickerViewController : UIViewController {
    UIDatePicker *datePicker;
    UILabel *dateLabel;
}
@property (strong, nonatomic) IBOutlet UIDatePicker *datePicker;
@property (strong, nonatomic) IBOutlet UILabel *dateLabel;
-(IBAction) getSelection;
@end
