//
//  twitterAppAppDelegate.h
//  twitterApp
//
//  Created by Neil Smyth on 8/12/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class twitterAppViewController;

@interface twitterAppAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) twitterAppViewController *viewController;

@end
