//
//  TableExampleAppDelegate.h
//  TableExample
//
//  Created by Neil Smyth on 7/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TableExampleViewController;

@interface TableExampleAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) TableExampleViewController *viewController;

@end
