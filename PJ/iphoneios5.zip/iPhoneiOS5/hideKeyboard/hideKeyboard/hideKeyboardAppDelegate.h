//
//  hideKeyboardAppDelegate.h
//  hideKeyboard
//
//  Created by Neil Smyth on 8/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class hideKeyboardViewController;

@interface hideKeyboardAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) hideKeyboardViewController *viewController;

@end
