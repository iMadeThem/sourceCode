//
//  TableExampleViewController.m
//  TableExample
//
//  Created by Neil Smyth on 7/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "TableExampleViewController.h"

@implementation TableExampleViewController
@synthesize colorNames;

// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView 
 numberOfRowsInSection:(NSInteger)section {
    return [self.colorNames count];
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView 
         cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
        static NSString *CellIdentifier = @"Cell";
        
        UITableViewCell *cell = [tableView 
                                 dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc]
                     initWithStyle:UITableViewCellStyleSubtitle
                     reuseIdentifier:CellIdentifier];
        }
        
        // Configure the cell.
        UIImage *cellImage = [UIImage imageNamed:@"apple.png"];
        cell.imageView.image = cellImage;
        NSString *colorString = [self.colorNames 
                                 objectAtIndex: [indexPath row]];
        
        cell.textLabel.text = colorString;
        NSString *subtitle = [NSString stringWithString: 
                              @"All about the color "];
        subtitle = [subtitle stringByAppendingString:colorString];
        cell.detailTextLabel.text = subtitle;
        return cell;
    } 

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    self.colorNames = [[NSArray alloc] 
                       initWithObjects:@"Red", @"Green",
                       @"Blue", @"Indigo", @"Violet", nil];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    self.colorNames = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
