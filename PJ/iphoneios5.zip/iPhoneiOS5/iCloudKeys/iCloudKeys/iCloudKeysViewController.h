//
//  iCloudKeysViewController.h
//  iCloudKeys
//
//  Created by Neil Smyth on 8/8/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface iCloudKeysViewController : UIViewController {
    UITextField *textField;
    NSUbiquitousKeyValueStore *keyStore;
}
@property (strong, nonatomic) IBOutlet UITextField *textField;
-(IBAction)saveKey;
@end
