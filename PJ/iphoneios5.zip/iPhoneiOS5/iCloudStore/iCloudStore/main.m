//
//  main.m
//  iCloudStore
//
//  Created by Neil Smyth on 8/8/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "iCloudStoreAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([iCloudStoreAppDelegate class]));
    }
}
