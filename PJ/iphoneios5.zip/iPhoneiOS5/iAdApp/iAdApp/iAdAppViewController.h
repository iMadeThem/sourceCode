//
//  iAdAppViewController.h
//  iAdApp
//
//  Created by Neil Smyth on 8/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <iAd/iAd.h>


@interface iAdAppViewController : UIViewController    
    <ADBannerViewDelegate>
{
    UITableView *tableView;
    ADBannerView *bannerView;
}
@property (strong, nonatomic) IBOutlet UITableView *tableView;
@end
