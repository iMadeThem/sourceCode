//
//  BooksViewController.h
//  TableView
//
//  Created by Neil Smyth on 7/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BooksViewController : UITableViewController
{
    NSArray *books;
} 
@property (nonatomic, strong) NSArray *books;
@end
