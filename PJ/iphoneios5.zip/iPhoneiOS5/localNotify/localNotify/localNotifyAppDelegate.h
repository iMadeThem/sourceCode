//
//  localNotifyAppDelegate.h
//  localNotify
//
//  Created by Neil Smyth on 8/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class localNotifyViewController;

@interface localNotifyAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) localNotifyViewController *viewController;

@end
