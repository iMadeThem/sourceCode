//
//  UnitConverterAppDelegate.h
//  UnitConverter
//
//  Created by Neil Smyth on 8/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class UnitConverterViewController;

@interface UnitConverterAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) UnitConverterViewController *viewController;

@end
