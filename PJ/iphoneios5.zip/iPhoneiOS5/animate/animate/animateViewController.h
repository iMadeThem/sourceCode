//
//  animateViewController.h
//  animate
//
//  Created by Neil Smyth on 8/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface animateViewController : UIViewController {
    UIView *boxView;
    float   scaleFactor;
    float   angle;
}
@property (nonatomic, strong) UIView *boxView;
@end
