//
//  archiveViewController.h
//  archive
//
//  Created by Neil Smyth on 8/3/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface archiveViewController : UIViewController {
    UITextField     *name;
    UITextField     *address;
    UITextField     *phone;
    NSString *dataFilePath;
}
@property (strong, nonatomic) IBOutlet UITextField *name;
@property (strong, nonatomic) IBOutlet UITextField *address;
@property (strong, nonatomic) IBOutlet UITextField *phone;
@property (strong, nonatomic) NSString *dataFilePath;
- (IBAction) saveData;


@end
