//
//  localNotifyViewController.h
//  localNotify
//
//  Created by Neil Smyth on 8/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface localNotifyViewController : UIViewController

@end
