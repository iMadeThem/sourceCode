//
//  coreDataViewController.h
//  coreData
//
//  Created by Neil Smyth on 8/10/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface coreDataViewController : UIViewController {
    UITextField *name;
    UITextField *address;
    UITextField *phone;
    UILabel     *status;
}
@property (strong, nonatomic) IBOutlet UITextField *name;
@property (strong, nonatomic) IBOutlet UITextField *address;
@property (strong, nonatomic) IBOutlet UITextField *phone;
@property (strong, nonatomic) IBOutlet UILabel *status;
- (IBAction) saveData;
- (IBAction) findContact;
@end
