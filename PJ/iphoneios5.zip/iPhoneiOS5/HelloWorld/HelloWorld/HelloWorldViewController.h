//
//  HelloWorldViewController.h
//  HelloWorld
//
//  Created by Neil Smyth on 7/29/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HelloWorldViewController : UIViewController

@end
