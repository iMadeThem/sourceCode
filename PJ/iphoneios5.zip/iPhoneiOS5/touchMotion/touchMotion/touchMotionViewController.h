//
//  touchMotionViewController.h
//  touchMotion
//
//  Created by Neil Smyth on 8/3/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface touchMotionViewController : UIViewController {
    UILabel *xCoord;
    UILabel *yCoord;
    CGPoint startPoint;
}
@property (strong, nonatomic) IBOutlet UILabel *xCoord;
@property (strong, nonatomic) IBOutlet UILabel *yCoord;
@property CGPoint startPoint;
@end
