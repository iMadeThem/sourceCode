//
//  movieAppDelegate.h
//  movie
//
//  Created by Neil Smyth on 8/5/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class movieViewController;

@interface movieAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) movieViewController *viewController;

@end
