//
//  iCloudKeysViewController.m
//  iCloudKeys
//
//  Created by Neil Smyth on 8/8/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "iCloudKeysViewController.h"

@implementation iCloudKeysViewController
@synthesize textField;

-(void)saveKey
{
    [keyStore setString:textField.text forKey:@"MyString"];
    [keyStore synchronize];
    
    NSLog(@"Save key");
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    keyStore = [[NSUbiquitousKeyValueStore alloc] init];
    
    NSString *storedString = [keyStore stringForKey:@"MyString"];
                           
    if (storedString != nil)
    {
        textField.text = storedString;
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self
            selector:@selector(ubiquitousKeyValueStoreDidChange:) 
            name:NSUbiquitousKeyValueStoreDidChangeExternallyNotification
            object:keyStore];

}

-(void) ubiquitousKeyValueStoreDidChange: (NSNotification *)notification
{
    NSLog(@"External Change detected");
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:@"Change detected"
                          message:@"Change detected"
                          delegate:nil 
                          cancelButtonTitle:@"Ok"
                          otherButtonTitles:nil, nil];
    [alert show];
    
    textField.text = [keyStore stringForKey:@"MyString"];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
