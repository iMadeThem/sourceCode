//
//  mapSampleViewController.h
//  mapSample
//
//  Created by Neil Smyth on 8/5/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

@interface mapSampleViewController : UIViewController
<MKMapViewDelegate>
{
    UIToolbar *toolBar;
    MKMapView *mapView;
}
@property (strong, nonatomic) IBOutlet MKMapView *mapView;
@property (strong, nonatomic) IBOutlet UIToolbar *toolBar;
@end
