//
//  mapSampleAppDelegate.h
//  mapSample
//
//  Created by Neil Smyth on 8/5/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class mapSampleViewController;

@interface mapSampleAppDelegate : UIResponder <UIApplicationDelegate>
{

}
@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) mapSampleViewController *viewController;

@end
