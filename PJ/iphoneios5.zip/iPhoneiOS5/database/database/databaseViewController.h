//
//  databaseViewController.h
//  database
//
//  Created by Neil Smyth on 8/3/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "/usr/include/sqlite3.h"

@interface databaseViewController : UIViewController {
    sqlite3 *contactDB;
    UITextField     *name;
    UITextField *address;
    UITextField *phone;
    UILabel *status;
    NSString        *databasePath;
}
@property (strong, nonatomic) IBOutlet UITextField *name;
@property (strong, nonatomic) IBOutlet UITextField *address;
@property (strong, nonatomic) IBOutlet UITextField *phone;
@property (strong, nonatomic) IBOutlet UILabel *status;
- (IBAction) saveData;
- (IBAction) findContact;

@end
