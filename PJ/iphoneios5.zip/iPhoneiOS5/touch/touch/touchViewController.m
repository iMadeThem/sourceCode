//
//  touchViewController.m
//  touch
//
//  Created by Neil Smyth on 8/3/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "touchViewController.h"

@implementation touchViewController
@synthesize touchStatus, methodStatus, tapStatus;

- (void) touchesBegan:(NSSet *)touches 
            withEvent:(UIEvent *)event {
    NSUInteger touchCount = [touches count];
    NSUInteger tapCount = [[touches anyObject] tapCount];
    methodStatus.text = @"touchesBegan";
    touchStatus.text = [NSString stringWithFormat:
                        @"%d touches", touchCount];
    tapStatus.text = [NSString stringWithFormat:
                      @"%d taps", tapCount];
} 

- (void) touchesMoved:(NSSet *)touches 
            withEvent:(UIEvent *)event {
    NSUInteger touchCount = [touches count];
    NSUInteger tapCount = [[touches anyObject] tapCount];
    methodStatus.text = @"touchesMoved";
    touchStatus.text = [NSString stringWithFormat:
                        @"%d touches", touchCount];
    tapStatus.text = [NSString stringWithFormat:
                      @"%d taps", tapCount];
}

- (void) touchesEnded:(NSSet *)touches 
            withEvent:(UIEvent *)event {
    NSUInteger touchCount = [touches count];
    NSUInteger tapCount = [[touches anyObject] tapCount];
    methodStatus.text = @"touchesEnded";
    touchStatus.text = [NSString stringWithFormat:
                        @"%d touches", touchCount];
    tapStatus.text = [NSString stringWithFormat:
                      @"%d taps", tapCount];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
