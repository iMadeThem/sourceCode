//
//  mapSampleViewController.m
//  mapSample
//
//  Created by Neil Smyth on 8/5/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "mapSampleViewController.h"

@implementation mapSampleViewController
@synthesize mapView, toolBar;

- (void)zoomIn: (id)sender
{
    MKUserLocation *userLocation = mapView.userLocation;
    MKCoordinateRegion region =
    MKCoordinateRegionMakeWithDistance (
        userLocation.location.coordinate, 50, 50);
    [mapView setRegion:region animated:NO];
}

- (void) changeMapType: (id)sender
{
    if (mapView.mapType == MKMapTypeStandard)
        mapView.mapType = MKMapTypeSatellite;
    else
        mapView.mapType = MKMapTypeStandard;
} 

- (void)mapView:(MKMapView *)mapView 
didUpdateUserLocation:
(MKUserLocation *)userLocation
{
    self.mapView.centerCoordinate = 
    userLocation.location.coordinate;
} 

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];

    mapView.delegate = self;
    
    mapView.showsUserLocation = YES;
    
    UIBarButtonItem *zoomButton = [[UIBarButtonItem alloc] 
                                   initWithTitle: @"Zoom"
                                   style:UIBarButtonItemStyleBordered
                                   target: self
                                   action:@selector(zoomIn:)];
    

    
    UIBarButtonItem *typeButton = [[UIBarButtonItem alloc] 
                                   initWithTitle: @"Type"
                                   style:UIBarButtonItemStyleBordered
                                   target: self
                                   action:@selector(changeMapType:)];
    
    NSArray *buttons = [[NSArray alloc] initWithObjects:zoomButton, typeButton, nil];
    
    toolBar.items = buttons;
    
    CLLocationCoordinate2D annotationCoord;
    
    annotationCoord.latitude = 47.640071;
    annotationCoord.longitude = -122.129598;
    
    MKPointAnnotation *annotationPoint = [[MKPointAnnotation alloc] init];
    annotationPoint.coordinate = annotationCoord;
    annotationPoint.title = @"Microsoft";
    annotationPoint.subtitle = @"Microsoft's headquarters";
    [mapView addAnnotation:annotationPoint]; 
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
