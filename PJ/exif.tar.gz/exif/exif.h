/* 
 * Exif parser header
 */ 

#include <ctype.h>
#include <stdio.h>

#define EXIT_FAILURE 1
#define EXIT_SUCCESS 0
#define PATH_MAX     1024
#define MAX_COMMENT_SIZE 2000
#define MAX_DATE_COPIES  10

//--------------------------------------------------------------------------
// JPEG markers consist of one or more 0xFF bytes, followed by a marker
// code byte (which is not an FF).  Here are the marker codes of interest
// in this program.  (See jdmarker.c for a more complete list.)
//--------------------------------------------------------------------------

#define M_SOF0  0xC0          // Start Of Frame N
#define M_SOF1  0xC1          // N indicates which compression process
#define M_SOF2  0xC2          // Only SOF0-SOF2 are now in common use
#define M_SOF3  0xC3
#define M_SOF5  0xC5          // NB: codes C4 and CC are NOT SOF markers
#define M_SOF6  0xC6
#define M_SOF7  0xC7
#define M_SOF9  0xC9
#define M_SOF10 0xCA
#define M_SOF11 0xCB
#define M_SOF13 0xCD
#define M_SOF14 0xCE
#define M_SOF15 0xCF
#define M_SOI   0xD8          // Start Of Image (beginning of datastream)
#define M_EOI   0xD9          // End Of Image (end of datastream)

#if 0
#define M_SOS   0xDA          // Start Of Scan (begins compressed data)
#define M_JFIF  0xE0          // Jfif marker
#define M_EXIF  0xE1          // Exif marker.  Also used for XMP data!
#define M_XMP   0x10E1        // Not a real tag (same value in file as Exif!)
#define M_COM   0xFE          // COMment 
#define M_DQT   0xDB
#define M_DHT   0xC4
#define M_DRI   0xDD
#define M_IPTC  0xED          // IPTC marker
#endif

typedef unsigned char uchar;

typedef enum {
    READ_METADATA = 1,
    READ_IMAGE = 2,
    READ_ALL = 3
} ReadMode_t;

typedef struct {
    uchar *data;
    int type;
    unsigned size;
} Section_t;

typedef struct {
    char FileName [PATH_MAX + 1];
    int   Height, Width;

#if 0
    struct {
	char Present;
	char ResolutionUnits;
	short XDensity;
	short YDensity;
    } JfifHeader;
    unsigned FileSize;
    char  CameraMake   [32];
    char  CameraModel  [40];
    char  DateTime     [20];

    int   Orientation;
    int   IsColor;
    int   Process;
    int   FlashUsed;
    float FocalLength;
    float ExposureTime;
    float ApertureFNumber;
    float Distance;
    float CCDWidth;
    float ExposureBias;
    float DigitalZoomRatio;
    int   FocalLength35mmEquiv; // Exif 2.2 tag - usually not present.
    int   Whitebalance;
    int   MeteringMode;
    int   ExposureProgram;
    int   ExposureMode;
    int   ISOequivalent;
    int   LightSource;
    int   DistanceRange;
    
    float xResolution;
    float yResolution;
    int   ResolutionUnit;
    
    char  Comments[MAX_COMMENT_SIZE];
    int   CommentWidthchars; // If nonzero, widechar comment, indicates number of chars.

    unsigned ThumbnailOffset;          // Exif offset to thumbnail
    unsigned ThumbnailSize;            // Size of thumbnail.
    unsigned LargestExifOffset;        // Last exif data referenced (to check if thumbnail is at end)

    char  ThumbnailAtEnd;              // Exif header ends with the thumbnail
                                       // (we can only modify the thumbnail if its at the end)
    int   ThumbnailSizeOffset;

    int  DateTimeOffsets[MAX_DATE_COPIES];
    int  numDateTimeTags;

    int GpsInfoPresent;
    char GpsLat[31];
    char GpsLong[31];
    char GpsAlt[20];
#endif
} ImageInfo_t;

void ErrFatal(const char *msg);
void dump(char *msg);
void ResetJpegSections(void);
void ParseFile(const char *FileName);
int ReadJpegFile(const char *FileName, ReadMode_t ReadMode);
int ReadJpegSections(FILE *InFile, ReadMode_t ReadMode);
void DiscardData(void);
void CheckSectionsAllocated(void);
void process_SOFn(const uchar *Data, int marker);
int Get16m(const void *Short);
