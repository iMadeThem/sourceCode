const char*version_string = "Version s20090425";
