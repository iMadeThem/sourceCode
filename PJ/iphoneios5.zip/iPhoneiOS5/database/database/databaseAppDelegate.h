//
//  databaseAppDelegate.h
//  database
//
//  Created by Neil Smyth on 8/3/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class databaseViewController;

@interface databaseAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) databaseViewController *viewController;

@end
