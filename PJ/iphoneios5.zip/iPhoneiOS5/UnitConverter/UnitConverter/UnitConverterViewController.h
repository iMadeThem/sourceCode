//
//  UnitConverterViewController.h
//  UnitConverter
//
//  Created by Neil Smyth on 8/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UnitConverterViewController : UIViewController {
    UITextField     *tempText;
    UILabel         *resultLabel;
}
@property (strong, nonatomic) IBOutlet UILabel *resultLabel;
@property (strong, nonatomic) IBOutlet UITextField *tempText;
- (IBAction)convertTemp:(id)sender;
@end
