//
//  iCloudStoreViewController.m
//  iCloudStore
//
//  Created by Neil Smyth on 8/8/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "iCloudStoreViewController.h"
#define UBIQUITY_CONTAINER_URL @"YOUR_ID_HERE.com.yourdomain.iCloudStore"

@implementation iCloudStoreViewController
@synthesize textView, documentURL, document;
@synthesize ubiquityURL, metadataQuery;

- (void)saveDocument
{
    self.document.userText = textView.text;
    [self.document saveToURL:ubiquityURL forSaveOperation:UIDocumentSaveForOverwriting
           completionHandler:^(BOOL success) {
               if (success){
                   NSLog(@"Saved to cloud for overwriting");
               } else {
                   NSLog(@"Not saved to cloud for overwriting");
               } 
           }];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    NSArray *dirPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    NSString *docsDir = [dirPaths objectAtIndex:0];
    
    NSString *dataFile = [docsDir stringByAppendingPathComponent: @"document.doc"];
    
    self.documentURL = [NSURL fileURLWithPath:dataFile];
    
    NSFileManager *filemgr = [NSFileManager defaultManager];
    
    ubiquityURL = [[filemgr URLForUbiquityContainerIdentifier:UBIQUITY_CONTAINER_URL] URLByAppendingPathComponent:@"Documents"];
    
    NSLog(@"iCloud path = %@", [ubiquityURL path]);
    
    if ([filemgr fileExistsAtPath:[ubiquityURL path]] == NO)
    {
        NSLog(@"iCloud Documents directory does not exist");
        [filemgr createDirectoryAtURL:ubiquityURL withIntermediateDirectories:YES attributes:nil error:nil];
    } else {
        NSLog(@"iCloud Documents directory exists");
    }
    
    ubiquityURL = [ubiquityURL URLByAppendingPathComponent:@"document.doc"];
    
    NSLog(@"Full ubiquity path = %@", [ubiquityURL path]);
    
    
    // Search for document in iCloud storage
    
    metadataQuery = [[NSMetadataQuery alloc] init];
    
    [metadataQuery setPredicate: [NSPredicate predicateWithFormat: @"%K like 'document.doc'",
                NSMetadataItemFSNameKey]];
    
    [metadataQuery setSearchScopes:[NSArray arrayWithObjects:NSMetadataQueryUbiquitousDocumentsScope,nil]];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(metadataQueryDidFinishGathering:) 
                name:NSMetadataQueryDidFinishGatheringNotification 
                object:metadataQuery];
    NSLog(@"starting query");
    [metadataQuery startQuery];

}

- (void)metadataQueryDidFinishGathering:(NSNotification *)notification {
    
    NSMetadataQuery *query = [notification object];
    
    [query disableUpdates];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NSMetadataQueryDidFinishGatheringNotification object:query];
    
    [query stopQuery];
    
    NSArray *results = [[NSArray alloc] initWithArray:[query results]];
    
    
    if ([results count] == 1)
    {        
        NSLog(@"File exists in cloud");
        ubiquityURL = [[results objectAtIndex:0] valueForAttribute:NSMetadataItemURLKey];
        
        self.document = [[MyDocument alloc] initWithFileURL:ubiquityURL];
        
        //self.document.userText = @"";
        
        [document openWithCompletionHandler:
         ^(BOOL success) { 
             if (success){
                 NSLog(@"Opened cloud doc");
                 textView.text = document.userText;
             } else {
                 NSLog(@"Not opened cloud doc");
             } 
         }];
        
    } else {
        NSLog(@"File does not exist in cloud");
        self.document = [[MyDocument alloc] initWithFileURL:ubiquityURL];
        
        [document saveToURL:ubiquityURL 
           forSaveOperation: UIDocumentSaveForCreating
          completionHandler:^(BOOL success) { 
              if (success){
                  NSLog(@"Saved to cloud");   
                  
              }  else {
                  NSLog(@"Failed to save to cloud");
              }
          }];
        

    }
         
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
