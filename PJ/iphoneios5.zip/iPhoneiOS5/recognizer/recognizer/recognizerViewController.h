//
//  recognizerViewController.h
//  recognizer
//
//  Created by Neil Smyth on 8/3/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface recognizerViewController : UIViewController
{
    UILabel *statusLabel;
}
@property (strong, nonatomic) IBOutlet UILabel *statusLabel;

@end
